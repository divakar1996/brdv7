package Connection;

public class MainConnection {
	public static void main(String []args){
		ConnectionInterface conn=FactoryPattern.getConnection("oracle");
		conn.myConnection();
	}

}
