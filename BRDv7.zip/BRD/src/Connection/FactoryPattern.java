package Connection;

public class FactoryPattern {
	static ConnectionInterface getConnection(String str){
		if(str.equalsIgnoreCase("oracle")){
			return new OracleConnection();
		}else
			return null;
	}
}
